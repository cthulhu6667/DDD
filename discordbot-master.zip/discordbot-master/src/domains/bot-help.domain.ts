export interface IBotHelp {
  caption: string;
  description: string;
}