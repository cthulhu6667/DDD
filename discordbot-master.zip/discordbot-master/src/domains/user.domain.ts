export interface IUser {
  id: string;
  username: string;
  discriminator: string;
  tag: string;
}